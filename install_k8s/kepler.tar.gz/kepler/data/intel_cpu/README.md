# CPU Model

[download_models.sh](./download_models.sh) downloads the latest Intel CPU products information, relates the CPU product name to its microarchitecture.

[product_architecure.csv](./product_architecure.csv) is the output of `download_models.sh`

Currently `product_architecture.csv` is not used in Kepler yet.
