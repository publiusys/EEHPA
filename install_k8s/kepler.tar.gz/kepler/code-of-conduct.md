Kepler follows [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/main/code-of-conduct.md)
