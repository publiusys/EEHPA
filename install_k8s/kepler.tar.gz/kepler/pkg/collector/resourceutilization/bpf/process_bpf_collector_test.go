package bpf

import (
	. "github.com/onsi/ginkgo/v2"
)

var _ = Describe("Test hc collector", func() {
})
